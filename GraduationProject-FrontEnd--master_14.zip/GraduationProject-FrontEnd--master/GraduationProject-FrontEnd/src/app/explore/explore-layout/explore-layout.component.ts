import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-explore-layout',
  templateUrl: './explore-layout.component.html',
  styleUrls: ['./explore-layout.component.css']
})
export class ExploreLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
