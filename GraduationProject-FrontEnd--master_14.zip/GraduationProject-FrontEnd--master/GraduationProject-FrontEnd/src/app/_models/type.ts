export class Type {
  constructor(public id?: number, public name?: string, public icon?: string) {}
}
