export class ProfileInfo {
  constructor(
    public fullname?: string,
    public email?: string,
    public phone?: string
  ) {}
}
