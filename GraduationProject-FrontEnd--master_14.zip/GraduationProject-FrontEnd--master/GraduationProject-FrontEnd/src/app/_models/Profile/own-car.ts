export class OwnCar {
    constructor(
        public imgName?: string,
        public carName?: string,
        public className?: string,
        public carDetailsId?: number,
        public userCarId?:number
    ){}
}
