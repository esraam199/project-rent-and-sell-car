export class SuggestForm {
  constructor(
    public priceRange?: number,
    public carState?: number,
    public carUsage?: number,
    public carCriteria?: number,
    public waysType?: number
  ) {}
}
