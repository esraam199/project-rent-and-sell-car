export class Photo {
  constructor(
    public previewImageSrc?: string,
    public thumbnailImageSrc?: string,
    public alt?: string,
  ) {}
}
