export class Class {
  constructor(public classId?: number, public className?: string) {}
}
