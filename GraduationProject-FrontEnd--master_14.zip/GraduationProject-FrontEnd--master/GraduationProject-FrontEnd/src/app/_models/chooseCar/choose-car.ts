export class ChooseCar {
  constructor(
    public className?: string,
    public imgName?: string,
    public carName?: string,
    public modelClassId?:number,
    public carDetailsId?:number
  ) {}
}
