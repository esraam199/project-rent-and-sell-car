export class Year {
  constructor(public year:string){}
}
