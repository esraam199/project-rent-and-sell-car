export class Brand {
  constructor(public id?: number, public name?: string, public icon?: string) {}
}
