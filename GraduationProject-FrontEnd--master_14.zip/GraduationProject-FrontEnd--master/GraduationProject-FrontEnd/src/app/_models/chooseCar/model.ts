export class Model {
  constructor(public id?: number, public name?: string) {}
}
