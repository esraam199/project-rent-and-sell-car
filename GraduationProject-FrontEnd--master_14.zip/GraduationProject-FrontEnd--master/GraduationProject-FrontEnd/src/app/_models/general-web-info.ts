export class GeneralWebInfo {
  constructor(
    public carsNo?: number,
    public modelNo?: number,
    public brandNo?: number
  ) {}
}
