export class SellData {
  constructor(
    public km?: number,
    public maintainance?: boolean,
    public guarntee?: boolean,
    public fabrique?: boolean,
    public notes?: string,
    public price?: number
  ) {}
}
